package Service;

import Repository.AnswerRepository;
import Model.Answer;
import dto.AnswerDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AnswerService {

    private final AnswerRepository answerRepository;

    @Autowired
    public AnswerService(AnswerRepository answerRepository) {
        this.answerRepository = answerRepository;
    }

    public List<AnswerDTO> getAllAnswers() {
        List<Answer> answers = answerRepository.findAll();
        return answers.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public AnswerDTO addAnswer(AnswerDTO answerDTO) {
        Answer answer = convertToEntity(answerDTO);
        Answer savedAnswer = answerRepository.save(answer);
        return convertToDTO(savedAnswer);
    }

    private AnswerDTO convertToDTO(Answer answer) {
        return null;
    }

    private Answer convertToEntity(AnswerDTO answerDTO) {
        return null;
    }
}
